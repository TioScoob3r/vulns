import axios from 'axios';
import * as cheerio from 'cheerio';
import { HEADERS, GOOGLE_SEARCH_DELAY } from './config.js';
import { delay } from './utils.js';

let lastSearchTime = 0;

export async function searchGoogle(dork) {
  try {
    const now = Date.now();
    const timeSinceLastSearch = now - lastSearchTime;
    
    if (timeSinceLastSearch < GOOGLE_SEARCH_DELAY) {
      const waitTime = GOOGLE_SEARCH_DELAY - timeSinceLastSearch;
      console.log(`[*] Waiting ${waitTime/1000} seconds before next Google search...`);
      await delay(waitTime);
    }
    
    console.log(`[+] Searching for: ${dork}`);
    const response = await axios.get(
      `https://www.google.com/search?q=${encodeURIComponent(dork)}`,
      { headers: HEADERS }
    );
    
    lastSearchTime = Date.now();
    
    const $ = cheerio.load(response.data);
    const urls = new Set();
    
    $('a').each((_, element) => {
      const href = $(element).attr('href');
      if (href?.startsWith('http') && !href.includes('google.com')) {
        const cleanUrl = href.split('&')[0].replace('/url?q=', '');
        if (cleanUrl.includes('=')) {
          urls.add(cleanUrl);
        }
      }
    });
    
    const uniqueUrls = Array.from(urls);
    console.log(`[+] Found ${uniqueUrls.length} potential target URLs`);
    
    return uniqueUrls;
  } catch (error) {
    if (error.response?.status === 429) {
      console.error('[!] Google rate limit detected. Waiting longer...');
      await delay(GOOGLE_SEARCH_DELAY * 2);
      return [];
    }
    console.error(`[-] Error searching Google: ${error.message}`);
    return [];
  }
}