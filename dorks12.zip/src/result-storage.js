import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const RESULTS_DIR = path.join(__dirname, '..', 'results');

export class ResultStorage {
  constructor() {
    this.setupResultsDirectory();
  }

  async setupResultsDirectory() {
    try {
      await fs.mkdir(RESULTS_DIR, { recursive: true });
      console.log('[+] Results directory created');
    } catch (error) {
      console.error('[-] Error creating results directory:', error.message);
    }
  }

  async saveVulnerableUrl(url, result) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const urlObj = new URL(url);
    const domain = urlObj.hostname;
    
    const resultDir = path.join(RESULTS_DIR, domain);
    await fs.mkdir(resultDir, { recursive: true });

    const filename = `${timestamp}_vulnerability.json`;
    const filepath = path.join(resultDir, filename);

    const data = {
      url,
      timestamp: new Date().toISOString(),
      columns: result.columns,
      tables: Array.from(result.tables),
      successfulPayloads: result.successfulPayloads
    };

    try {
      await fs.writeFile(filepath, JSON.stringify(data, null, 2));
      console.log(`[+] Saved vulnerability details to: ${filepath}`);
    } catch (error) {
      console.error(`[-] Error saving results: ${error.message}`);
    }
  }

  async saveScanSummary(stats, vulnerableUrls) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const summaryPath = path.join(RESULTS_DIR, `scan_summary_${timestamp}.json`);

    const summary = {
      timestamp: new Date().toISOString(),
      stats,
      vulnerableUrls: Array.from(vulnerableUrls.entries()).map(([url, details]) => ({
        url,
        ...details
      }))
    };

    try {
      await fs.writeFile(summaryPath, JSON.stringify(summary, null, 2));
      console.log(`[+] Saved scan summary to: ${summaryPath}`);
    } catch (error) {
      console.error('[-] Error saving scan summary:', error.message);
    }
  }
}