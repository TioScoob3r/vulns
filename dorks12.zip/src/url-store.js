// Store for tracking tested URLs and vulnerable sites
class URLStore {
  constructor() {
    this.testedUrls = new Set();
    this.vulnerableUrls = new Map(); // URL -> successful payloads
    this.seenDomains = new Map(); // domain -> Set of paths
    this.lastTestedTime = new Map(); // URL -> timestamp
  }

  isUrlTested(url) {
    const normalizedUrl = this.normalizeUrl(url);
    const domain = this.getDomain(url);
    
    if (this.testedUrls.has(normalizedUrl)) {
      return true;
    }

    if (domain && this.seenDomains.has(domain)) {
      const paths = this.seenDomains.get(domain);
      const urlPath = new URL(url).pathname;
      
      if (paths.size >= 5) {
        const lastTest = this.lastTestedTime.get(domain) || 0;
        const timeSinceLastTest = Date.now() - lastTest;
        
        if (timeSinceLastTest < 300000) { // 5 minutes cooldown
          console.log(`[*] Skipping ${url} - Domain rate limited`);
          return true;
        } else {
          paths.clear();
          this.lastTestedTime.set(domain, Date.now());
        }
      }
    }

    return false;
  }

  normalizeUrl(url) {
    try {
      const urlObj = new URL(url);
      ['utm_source', 'utm_medium', 'utm_campaign', 'ref', 'fbclid'].forEach(param => {
        urlObj.searchParams.delete(param);
      });
      return urlObj.origin + urlObj.pathname;
    } catch {
      return url;
    }
  }

  getDomain(url) {
    try {
      return new URL(url).hostname;
    } catch {
      return null;
    }
  }

  markUrlAsTested(url) {
    const normalizedUrl = this.normalizeUrl(url);
    const domain = this.getDomain(url);
    
    this.testedUrls.add(normalizedUrl);
    
    if (domain) {
      if (!this.seenDomains.has(domain)) {
        this.seenDomains.set(domain, new Set());
      }
      this.seenDomains.get(domain).add(new URL(url).pathname);
      this.lastTestedTime.set(domain, Date.now());
    }
  }

  addVulnerableUrl(url, payload) {
    const normalizedUrl = this.normalizeUrl(url);
    if (!this.vulnerableUrls.has(normalizedUrl)) {
      this.vulnerableUrls.set(normalizedUrl, []);
    }
    if (!this.vulnerableUrls.get(normalizedUrl).includes(payload)) {
      this.vulnerableUrls.get(normalizedUrl).push(payload);
    }
  }

  getStats() {
    return {
      totalTested: this.testedUrls.size,
      totalVulnerable: this.vulnerableUrls.size,
      uniqueDomains: this.seenDomains.size,
      recentlyTestedDomains: Array.from(this.lastTestedTime.entries())
        .filter(([_, time]) => Date.now() - time < 300000)
        .length
    };
  }
}

export const urlStore = new URLStore();