// General utility functions
export const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

export function sanitizeFilename(filename) {
  return filename.replace(/[^a-zA-Z0-9]/g, '_');
}

export function formatTimestamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

export function extractDomain(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return null;
  }
}